package com.techelevator.util;

public class BasicLoggerException extends RuntimeException {

	public BasicLoggerException(String message) {
		super(message);
	}
}
